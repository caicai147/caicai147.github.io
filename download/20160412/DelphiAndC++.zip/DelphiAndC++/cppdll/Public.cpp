#include "Public.h"
#include <string.h>

void mystrncpy(char *dest, const char *src, size_t n)
{
	strncpy(dest,src,n);
	dest[n] = '\0';
}