#include<iostream>

using namespace std;

class Base{
	public:
		Base(){
			cout << "父类的构造 Base()" << endl;
		}
		//父类的析构方法声明为虚方法
		virtual ~Base(){
			cout << "父类的析构 ~Base()" << endl;
		}
};

class Derived : public Base{
	public:
		Derived(){
			cout << "子类的构造 Derived()" << endl;
		}
		~Derived(){
			cout << "子类的析构 ~Derived()" << endl;
		}
};

int main()
{
	//通过父类指针构造、析构子类对象
	Base *bpt = new Derived();
	delete bpt;
	cout << endl;

	//通过子类指针构造、析构子类对象
	Derived *dpt = new Derived();
	delete dpt;
	cout << endl;

	//直接声明一个父类对象
	Base b;
	cout << endl;

	//直接声明一个子类对象
	Derived d;
	cout << endl;

	cout << "return 0之前" << endl << endl;
	return 0;
	cout << "return 0之后" << endl << endl;
}
