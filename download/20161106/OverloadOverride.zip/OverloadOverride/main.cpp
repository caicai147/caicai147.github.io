#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

class Base{
	public:
		void testOverload(){
			cout << "Base::testOverload" << endl;
		}
		virtual void testOverride(){
			cout << "Base::testOverride" << endl;
		}
};

class Derived : public Base{
	public:
		void testOverload(){
			cout << "Derived::testOverload" << endl;
		}
		void testOverride(){
			cout << "Derived::testOverride" << endl;
		}
};

int main()
{
	Base *b = new Derived();

	b->testOverride();
	b->testOverload();

	system("pause");
	return 0;
}