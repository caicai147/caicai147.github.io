#include "test_interface.h"

CTestImpl::CTestImpl()
{
	m_iRefCount = 0;
	InitializeCriticalSection(&m_RefLock);
}

CTestImpl::~CTestImpl()
{
	DeleteCriticalSection(&m_RefLock);
}

int __stdcall CTestImpl::Add(const int a, const int b)
{
	return (a + b);
}

int __stdcall CTestImpl::Sub(const int a, const int b)
{
	return (a - b);
}

int __stdcall CTestImpl::GetRefCount()
{
	return m_iRefCount;
}