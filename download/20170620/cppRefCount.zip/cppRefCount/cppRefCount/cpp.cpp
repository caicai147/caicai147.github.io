#include "cpp.h"

ITestInterface* __stdcall NewCppImplementation()
{
	ITestInterface* pTest= NULL;
	pTest = new CTestImpl();
	return pTest;
}