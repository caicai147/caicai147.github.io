#include<stdio.h>
#include<stdlib.h>
#include "cpp.h"

int main()
{
	ITestInterface* pTest1;
	ITestInterface* pTest2;
	pTest1 = NewCppImplementation();
	printf("pTest1���ü��� = %d\n", pTest1->GetRefCount());

	pTest2 = pTest1;
	printf("pTest1���ü��� = %d\n", pTest1->GetRefCount());

	pTest2 = NULL;
	printf("pTest1���ü��� = %d\n", pTest1->GetRefCount());

	system("pause");
	return 0;
}