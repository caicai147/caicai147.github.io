#include <stdio.h>
#include <string.h>
#include <windows.h>

#define I_OK 1

//�������ü���
struct IUnKnown
{
	virtual unsigned long __stdcall QueryInterface( const char * iid, struct IUnKnown **ppv ) = 0;
	virtual unsigned long __stdcall AddRef() = 0;
	virtual unsigned long __stdcall Release() = 0;
};

class ITestInterface: public IUnKnown
{
public:
	virtual int __stdcall Add(const int a, const int b) = 0;
	virtual int __stdcall Sub(const int a, const int b) = 0;
	virtual int __stdcall GetRefCount() = 0;
};

class CTestImpl: public ITestInterface
{
protected:
	CRITICAL_SECTION m_RefLock;
	int m_iRefCount;
public:
	virtual unsigned long __stdcall QueryInterface( const char * iid, IUnKnown **ppv ){
		return I_OK;
	}
	virtual unsigned long __stdcall AddRef(){
		EnterCriticalSection(&m_RefLock);
		m_iRefCount++;
		LeaveCriticalSection(&m_RefLock);
		return I_OK;
	}
	virtual unsigned long __stdcall Release(){
		EnterCriticalSection(&m_RefLock);
		m_iRefCount--;
		LeaveCriticalSection(&m_RefLock);
		if(m_iRefCount <= 0)
			delete this;
		return I_OK;
	}
	
	CTestImpl();
	~CTestImpl();
	virtual int __stdcall Add(const int a, const int b);
	virtual int __stdcall Sub(const int a, const int b);
	virtual int __stdcall GetRefCount();
};