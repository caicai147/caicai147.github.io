#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

class Point{
	public:
		Point( float xval );
		virtual ~Point();

		float x() const;
		static int PointCount();

	protected:
		virtual ostream& print( ostream &os ) const;
		
		float _x;
		static int _point_count;
};

class Point2d: public Point{
	public:
		Point2d ( float xval, float yval );
		~Point2d();
		
		float y() const;
		ostream& print( ostream &os ) const;
	protected:
		float _y;
};

//Point����ʵ��
Point::Point( float xval ){
	_x = xval;
	_point_count ++;
	cout << "�ȹ��츸��Point()" << endl;
}

Point::~Point(){
	_x = 0;
	_point_count --;
	cout << "����������~Point()" << endl;
}

float Point::x() const{
	return _x;
}

int Point::PointCount(){
	return _point_count;
}

ostream& Point::print( ostream &os ) const{
	os << "x=" << _x << endl;
	return os;
}

int Point::_point_count = 0;	//�����ʼ��C++��ľ�̬����

//Point2d����ʵ��
//ע������ʵ�ֹ��췽��ʱ�ĸ�ʽ
Point2d::Point2d( float xval, float yval ): Point( xval ){
	_y = yval;
	cout << "�ٹ�������Point2d()" << endl;
}

float Point2d::y() const{
	return _y;
}

Point2d::~Point2d(){
	cout << "����������~Point2d()" << endl;
}

ostream& Point2d::print( ostream &os ) const{
	os << "x=" << _x << ", y=" << _y << endl;
	return os;
}

int main()
{
	cout << "sizeof(Point) = " << sizeof(Point) << endl;
	cout << "sizeof(Point2d) = " << sizeof(Point2d) << endl << endl;
	
	Point pt(1);
	Point2d pt2d(1, 2);
	cout << "sizeof(pt) = " << sizeof(pt) << endl;
	cout << "sizeof(pt2d) = " << sizeof(pt2d) << endl << endl;

	Point2d *_pt2d = new Point2d(1, 2);
	_pt2d->print(cout);

	delete _pt2d;

	system("pause");
	return 0;
}