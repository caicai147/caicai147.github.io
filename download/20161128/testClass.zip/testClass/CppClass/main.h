#include "TestClass.h"

extern "C"
{
	testInterface* __stdcall getClass(int type);
}