#include<iostream>
#include "main.h"

using namespace std;

testInterface* __stdcall getClass(int type)
{
	testInterface *tb = NULL;
	if (1 == type){
		tb = new testDerivedA();
		tb->value = 1;
	}
	else if (2 == type){
		tb = new testDerivedB();
		tb->value = 2;
	}

	return tb;
}