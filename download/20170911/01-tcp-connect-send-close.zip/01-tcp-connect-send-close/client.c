#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    const char *ip;
    int port;
    int sleepSec;
    if(argc <= 2){
        ip = "192.168.163.41";
        port = 10011;
        sleepSec = 0;
    }else{
        ip = argv[1];
        port = atoi(argv[2]);
        sleepSec = atoi(argv[3]);
    }

    printf("%s:%d\n", ip, port);

    struct sockaddr_in server_address;
    bzero(&server_address, sizeof(server_address));
    server_address.sin_family = AF_INET;
    inet_pton(AF_INET, ip, &server_address.sin_addr);
    server_address.sin_port = htons(port);

    int sockfd = socket(PF_INET, SOCK_STREAM, 0);
    assert(socket > 0);
   
    if(connect(sockfd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0){
        printf("connect failed\n");
        return -1;
    }
   
    char *c = "c";
    int len = 0;
    len = send(sockfd, c, strlen(c), 0);
    printf("send length:%d; %s\n", len, c);
    len = send(sockfd, c, strlen(c), 0);
    printf("send length:%d; %s\n", len, c);

    char *str = "string";
    len = send(sockfd, str, strlen(str), 0);
    printf("send length:%d; %s\n", len, str);

    printf("sleep %d second\n", sleepSec);
    usleep(sleepSec * 1000 * 1000);
   
    printf("close\n");
    close(sockfd);

    return 0;
}
