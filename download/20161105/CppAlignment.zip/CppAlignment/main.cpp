#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

class Concrete{
	private:
		int val;
		char c1;
		char c2;
		char c3;
};

int main()
{
	cout << "sizeof(Concrete) = " << sizeof(Concrete) << endl;

	system("pause");
	return 0;
}