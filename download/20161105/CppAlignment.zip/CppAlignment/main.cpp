#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

class Concrete{
	public:
		int val;
		char bit1;
		char bit2;
		char bit3;
};

int main()
{
	cout << "sizeof(Concrete) = " << sizeof(Concrete) << endl;

	system("pause");
	return 0;
}