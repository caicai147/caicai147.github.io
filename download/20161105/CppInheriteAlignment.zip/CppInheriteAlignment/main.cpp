#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

class Concrete1{
	public:
		int val;
		char bit1;
};

class Concrete2 : public Concrete1{
	public:
		char bit2;
};

class Concrete3 : public Concrete2{
	public:
		char bit3;
};

int main()
{
	cout << "sizeof(Concrete1) = " << sizeof(Concrete1) << endl;
	cout << "sizeof(Concrete2) = " << sizeof(Concrete2) << endl;
	cout << "sizeof(Concrete3) = " << sizeof(Concrete3) << endl;

	system("pause");
	return 0;
}